Deep & Crust Pizza website bundle

To make upload easier from an iPhone, all files are in the ZIP's top level:
- index.html
- deep-crust-logo.jpg
- food-1.jpg, food-2.jpg, food-3.jpg, food-4.jpg

The logo and food images were cropped from the menu image you supplied.

iPhone upload steps:
1. Download this ZIP and save it to the Files app.
2. In Files, tap the ZIP once to unzip it.
3. Open https://github.com/yungzoe123/deep-crust-pizza
4. Choose Add file > Upload files.
5. Select index.html and all five JPG files from the unzipped folder.
6. Commit changes directly to main.
7. Wait a few minutes, then open https://yungzoe123.github.io/deep-crust-pizza/

The website is bilingual English/Spanish and includes the logo, menu prices, cropped food photos, birthday offers, catering/party-room information, DJ/karaoke details, and call/WhatsApp links. Verify menu prices and hours before sharing. Weekend Uber Eats hours were unclear and are shown as needing confirmation.
